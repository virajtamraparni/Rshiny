library(shiny)
library(ggplot2)
library(scales)
library(maps)
library(dplyr)


crime_data  = read.csv("per_capita_crime_rate.csv")
my_crime <- as.character(unique(crime_data$Crime))

# Define UI for application that draws a histogram
shinyUI(fluidPage(
  ###################### first row starts here
  fluidRow(
    column(12,
           # Application title takes all 12 column spaces
           titlePanel("Crime Rate Analysis in The United States of America")
    )),
  
  ###################### 2nd row starts here. 2 columns 
  fluidRow(
    column(5,
           wellPanel(
             selectInput("selectedCrime", 
                         label = "Crime",
                         choices = my_crime, 
                         selected = my_crime[1]),
             
             sliderInput("myYears",
                         "Crime Year",
                         min = as.numeric(1975),
                         max = as.numeric(2015),
                         value = as.numeric(1980),
                         step = 1),
             
           )
    ),
    column(7, 
           plotOutput("myMap",height = "300px", width="550px")
    )      
  ),
  
  ###################### 3rd row starts here. 2 columns
  fluidRow(
    column(5, 
           ggiraphOutput("myPlot",height = "1000px",width="250%")
    ),
    column(6, 
           plotOutput("my_crime",height = "400px", width="550px")
    )  
  )
  
  
))
