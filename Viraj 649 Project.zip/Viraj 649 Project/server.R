library(ggplot2)
library(ggiraph)
library(scales)
library(dplyr)
library(maps)

crime_data = read.csv("per_capita_crime_rate.csv") 

mdat <- map_data("state")

shinyServer(function(input, output) {
  
  # setting the reactive environment 
  dataInput <- reactive({
    subset(crime_data,
           Year==input$myYears & 
             Crime==input$selectedCrime)
  })
  
  dataInput1 <- reactive({
    subset(crime_data,
             Crime==input$selectedCrime)
  })
  
  # PLotting the bar plots
  output$myPlot <- renderggiraph({
    
    a = ggplot(dataInput(), aes(reorder(State,Rate),Rate)) + 
      geom_point_interactive(color="black", size=3,aes(tooltip = paste(State, Rate), data_id = State)) +
      labs(title = "Per Capita Crime Rate",
           x = "",
           y = "Crime Rate") +
      guides(color = FALSE, size = FALSE) +
      coord_flip() + 
      theme_bw() 
    
    b = ggplot(dataInput1(), aes(x = Year, y = Rate)) + 
      geom_line_interactive(aes(tooltip = Rate, data_id = State, color = State),
                            hover_css = "fill: none; stroke-width:3; stroke:DarkRed") +
      geom_point_interactive(aes(x = Year, y = Rate, data_id = State, color = State, tooltip = paste(State, Rate))) + 
      theme_bw() + 
      theme(legend.position = "bottom") + 
      guides(color = FALSE, size = FALSE) +
      ylab("Per Capita Crime Rate")
    
      ggiraph(ggobj =  a + b,
            width_svg = 20, height_svg = 16,
            options = list(
              opts_hover_inv(css = "opacity: 0")))
  })
  
  output$myMap <- renderPlot({ 
    combdat <- merge(mdat, dataInput(), by.x=c('region'), 
                     by.y=c('State'), all.x=TRUE)
    odat <- combdat[order(combdat$order),]
    ggplot(odat, aes(x=long, y=lat,group=group)) +
      geom_polygon(aes(fill=Rate), colour = alpha("white", 0.2)) + 
      theme_void() + scale_fill_continuous(low="orange", high="red") +
      theme(
        legend.position = "right",
        # text = element_blank(), 
        line = element_blank()) 
    
  })
  
  output$my_crime <- renderPlot({
    
    # sDat <- dataInput() %>% 
    #   arrange(-Rate)
    # topState <- sDat$State[1]
    # subDat <- crime_data %>% 
    #   filter(State == topState, Crime == input$selectedCrime)
    
    # ggplot(dataInput(), aes(x = Year, y = Rate, color = State)) + 
    #   geom_line_interactive(aes(tooltip = Rate)) +
    #   theme_bw() + 
    #   theme(legend.position = "bottom") + 
    #   guides(colour = guide_legend(nrow = 2)) + 
    #   ylab("Per Capita Crime Rate")
  })
  
  
})
